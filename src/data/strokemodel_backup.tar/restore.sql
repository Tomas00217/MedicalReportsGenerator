--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE strokemodel;
--
-- Name: strokemodel; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE strokemodel WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE strokemodel OWNER TO postgres;

\connect strokemodel

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: strokehealthcaremodel_admittancedepartmentmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_admittancedepartmentmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_admittancedepartmentmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_afibfluttermodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_afibfluttermodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_afibfluttermodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_arrivalmodemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_arrivalmodemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_arrivalmodemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_bleedingantidotemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_bleedingantidotemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_bleedingantidotemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_carotidstenosisfollowuptimingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_carotidstenosislevelmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_carotidstenosislevelmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_carotidstenosislevelmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_departmenttypemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_departmenttypemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_departmenttypemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_dischargedestinationmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_dischargedestinationmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_dischargedestinationmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_dischargefacilitydepartmentmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_dischargefacilitydepartmentmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_dischargefacilitydepartmentmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_dischargefacilitytypemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_dischargefacilitytypemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_dischargefacilitytypemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_gcslevelmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_gcslevelmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_gcslevelmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_hospitalizedinmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_hospitalizedinmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_hospitalizedinmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_imagingdonemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_imagingdonemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_imagingdonemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_imagingtypemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_imagingtypemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_imagingtypemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_inrmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_inrmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_inrmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_insulintimingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_insulintimingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_insulintimingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_ivtapplicationlocationmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_ivtapplicationlocationmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_ivtapplicationlocationmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_ivttreatmentmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_ivttreatmentmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_ivttreatmentmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_modecontactmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_modecontactmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_modecontactmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_mticiscoremodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_mticiscoremodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_mticiscoremodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_nimodipinetimingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_nimodipinetimingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_nimodipinetimingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_nothrombectomyreasonmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_nothrombectomyreasonmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_nothrombectomyreasonmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_nothrombolysisreasonmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_nothrombolysisreasonmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_nothrombolysisreasonmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_occupationaltherapydonemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_occupationaltherapydonemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_occupationaltherapydonemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_paracetamolmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_paracetamolmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_paracetamolmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_paracetamoltimingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_paracetamoltimingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_paracetamoltimingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_physiotherapydonemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_physiotherapydonemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_physiotherapydonemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_postacutecaremodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_postacutecaremodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_postacutecaremodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_posttreatmentimagingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_posttreatmentimagingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_posttreatmentimagingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_sexmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_sexmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_sexmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_smokingcessationmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_smokingcessationmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_smokingcessationmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_speechtherapydonemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_speechtherapydonemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_speechtherapydonemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_strokehealthcaremodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_strokehealthcaremodel (
    subject_id integer NOT NULL,
    label character varying(30) NOT NULL,
    validator_id integer,
    study_id integer,
    patient_date_created date NOT NULL,
    patient_owner integer,
    patient_data_updated date,
    age integer NOT NULL,
    wake_up_stroke boolean,
    hospital_stroke boolean,
    sleep_timestamp timestamp with time zone,
    onset_timestamp timestamp with time zone,
    onset_time_known boolean,
    hospital_timestamp timestamp with time zone,
    first_hospital boolean NOT NULL,
    first_arrival_hospital character varying(20),
    prenotification boolean,
    risk_hypertension boolean,
    risk_diabetes boolean,
    risk_hyperlipidemia boolean,
    risk_atrial_fibrilation boolean,
    risk_congestive_heart_failure boolean,
    risk_smoker_last_10_years boolean,
    risk_smoker boolean,
    risk_previous_stroke boolean,
    risk_previous_ischemic_stroke boolean,
    risk_previous_hemorrhagic_stroke boolean,
    risk_coronary_artery_disease_or_myocardial_infarction boolean,
    risk_hiv boolean,
    risk_covid boolean,
    risk_other boolean,
    before_onset_antidiabetics boolean,
    before_onset_antihypertensives boolean,
    before_onset_asa boolean,
    before_onset_cilostazol boolean,
    before_onset_clopidrogel boolean,
    before_onset_ticagrelor boolean,
    before_onset_ticlopidine boolean,
    before_onset_prasugrel boolean,
    before_onset_dipyridamol boolean,
    before_onset_other_antiplatelet boolean,
    before_onset_warfarin boolean,
    before_onset_dabigatran boolean,
    before_onset_rivaroxaban boolean,
    before_onset_apixaban boolean,
    before_onset_edoxaban boolean,
    before_onset_other_anticoagulant boolean,
    before_onset_statin boolean,
    before_onset_heparin boolean,
    before_onset_contraception boolean,
    before_onset_other boolean,
    glucose double precision,
    cholesterol double precision,
    sys_blood_pressure integer,
    dia_blood_pressure integer,
    nihss_score integer,
    prestroke_mrs integer,
    gcs_score integer,
    imaging_timestamp timestamp with time zone,
    imaging_within_hour boolean,
    old_infarcts_cortical boolean,
    old_infarcts_subcortical boolean,
    old_infarcts_brainstem boolean,
    aspects_score integer,
    occlusion_on_angio boolean,
    occlusion_left_mca_m1 boolean,
    occlusion_left_mca_m2 boolean,
    occlusion_left_mca_m3 boolean,
    occlusion_left_aca boolean,
    occlusion_left_pca_p1 boolean,
    occlusion_left_pca_p2 boolean,
    occlusion_left_cae boolean,
    occlusion_left_cai boolean,
    occlusion_right_mca_m1 boolean,
    occlusion_right_mca_m2 boolean,
    occlusion_right_mca_m3 boolean,
    occlusion_right_aca boolean,
    occlusion_right_pca_p1 boolean,
    occlusion_right_pca_p2 boolean,
    occlusion_right_cae boolean,
    occlusion_right_cai boolean,
    occlusion_ba boolean,
    occlusion_va boolean,
    perfusion_deficit_medial boolean,
    perfusion_deficit_anterior boolean,
    perfusion_deficit_posterior boolean,
    perfusion_deficit_carotid boolean,
    perfusion_deficit_bilateral_stenosis boolean,
    perfusion_deficit_done boolean,
    perfusion_core integer,
    hypoperfusion_core integer,
    thrombolysis boolean,
    ivt_antidote boolean,
    ivt_dose integer,
    bolus_timestamp timestamp with time zone,
    door_to_needle integer,
    thrombectomy boolean,
    puncture_timestamp timestamp with time zone,
    door_to_groin integer,
    reperfusion_timestamp timestamp with time zone,
    transfer_timestamp timestamp with time zone,
    door_to_door integer,
    complications_perforation boolean,
    complications_dissection boolean,
    complications_embolization boolean,
    complications_hematoma boolean,
    complications_other boolean,
    bleeding_volume_value integer,
    bleeding_volume_over_30 boolean,
    infratentorial_source boolean,
    bleeding_source boolean,
    intraventricular_hemorrhage boolean,
    bleeding_reason_hypertension boolean,
    bleeding_reason_aneurysm boolean,
    bleeding_reason_malformation boolean,
    bleeding_reason_anticoagulant boolean,
    bleeding_reason_angiopathy boolean,
    bleeding_reason_other boolean,
    neurosurgery boolean,
    ich_treatment_evacuation boolean,
    ich_treatment_drainage boolean,
    ich_treatment_craniectomy boolean,
    hunt_hess_score integer,
    sah_treatment_coiling boolean,
    sah_treatment_clipping boolean,
    sah_treatment_drainage boolean,
    sah_treatment_craniectomy boolean,
    sah_treatment_other boolean,
    nimodipine boolean,
    cvt_treatment_anticoagulation boolean,
    cvt_treatment_thrombectomy boolean,
    cvt_treatment_thrombolysis boolean,
    cvt_treatment_neurosurgery boolean,
    stroke_mimics_ivt boolean,
    ventilator boolean,
    hemicraniectomy boolean,
    carotid_arteries_imaging boolean,
    carotid_stenosis boolean,
    carotid_stenosis_followup boolean,
    holter_monitoring boolean,
    etiology_large_artery boolean,
    etiology_cardioembolism boolean,
    etiology_other boolean,
    etiology_cryptogenic_stroke boolean,
    etiology_small_vessel boolean,
    thromboembolism_lduh boolean,
    thromboembolism_lmwh boolean,
    thromboembolism_ipc boolean,
    thromboembolism_gcs boolean,
    thromboembolism_warfarin boolean,
    thromboembolism_vfp boolean,
    thromboembolism_oral_factorxa_inhibitor boolean,
    thromboembolism_other boolean,
    post_stroke_pneumonia boolean,
    post_stroke_dvt boolean,
    post_stroke_embolism boolean,
    post_stroke_infection boolean,
    post_stroke_sores boolean,
    post_stroke_sepsis boolean,
    post_stroke_extension boolean,
    post_stroke_other boolean,
    post_treatment_infarction boolean,
    post_treatment_no_bleeding boolean,
    post_treatment_remote boolean,
    post_treatment_hi_i boolean,
    post_treatment_hi_ii boolean,
    post_treatment_ph_i boolean,
    post_treatment_ph_ii boolean,
    temp_check_day_one integer,
    temp_check_day_two integer,
    temp_check_day_three integer,
    fever boolean,
    glucose_check_day_one integer,
    glucose_check_day_two integer,
    glucose_check_day_three integer,
    glucose_level boolean,
    insulin boolean,
    discharge_date date NOT NULL,
    discharge_mrs integer,
    discharge_nihss_score integer,
    discharge_antidiabetics boolean,
    discharge_antihypertensives boolean,
    discharge_asa boolean,
    discharge_cilostazol boolean,
    discharge_clopidrogel boolean,
    discharge_ticagrelor boolean,
    discharge_ticlopidine boolean,
    discharge_prasugrel boolean,
    discharge_dipyridamol boolean,
    discharge_warfarin boolean,
    discharge_dabigatran boolean,
    discharge_rivaroxaban boolean,
    discharge_apixaban boolean,
    discharge_edoxaban boolean,
    discharge_statin boolean,
    discharge_heparin boolean,
    discharge_anticoagulant_recommended boolean,
    discharge_other_anticoagulant boolean,
    discharge_antiplatelet_recommended boolean,
    discharge_other_antiplatelet boolean,
    discharge_other boolean,
    contact_date date,
    three_m_mrs integer,
    admittance_department_id integer,
    afib_flutter_id integer,
    arrival_mode_id integer,
    bleeding_antidote_id integer,
    carotid_stenosis_followup_timing_id integer,
    carotid_stenosis_level_id integer,
    department_type_id integer,
    discharge_destination_id integer NOT NULL,
    discharge_facility_department_id integer,
    discharge_facility_type_id integer,
    gcs_level_id integer,
    hospitalized_in_id integer,
    imaging_done_id integer,
    imaging_type_id integer,
    inr_id integer,
    insulin_timing_id integer,
    ivt_application_location_id integer,
    ivt_treatment_id integer,
    mode_contact_id integer,
    mtici_score_id integer,
    nimodipine_timing_id integer,
    no_thrombectomy_reason_id integer,
    no_thrombolysis_reason_id integer,
    occup_physiotherapy_done_id integer,
    paracetamol_id integer,
    paracetamol_timing_id integer,
    physiotherapy_done_id integer,
    post_acute_care_id integer NOT NULL,
    post_treatment_imaging_id integer,
    sex_id integer NOT NULL,
    smoking_cessation_id integer,
    speech_therapy_done_id integer,
    stroke_management_appointment_id integer,
    stroke_mimics_diagnosis_id integer,
    stroke_type_id integer NOT NULL,
    swallowing_assessment_by_id integer,
    swallowing_screening_done_id integer,
    swallowing_screening_timing_id integer,
    swallowing_screening_type_id integer,
    tia_clinical_features_id integer,
    tia_symptoms_duration_id integer
);


ALTER TABLE public.strokehealthcaremodel_strokehealthcaremodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_strokemanagementappointmentmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_strokemanagementappointmentmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_strokemanagementappointmentmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_strokemimicsdiagnosismodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_strokemimicsdiagnosismodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_strokemimicsdiagnosismodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_stroketypemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_stroketypemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_stroketypemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_swallowingassessmentmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_swallowingassessmentmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_swallowingassessmentmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_swallowingscreeningdonemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_swallowingscreeningdonemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_swallowingscreeningdonemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_swallowingscreeningtimingmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_swallowingscreeningtimingmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_swallowingscreeningtimingmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_swallowingscreeningtypemodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_swallowingscreeningtypemodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_swallowingscreeningtypemodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_tiaclinicalfeaturesmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_tiaclinicalfeaturesmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_tiaclinicalfeaturesmodel OWNER TO postgres;

--
-- Name: strokehealthcaremodel_tiasymptomsdurationmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strokehealthcaremodel_tiasymptomsdurationmodel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE public.strokehealthcaremodel_tiasymptomsdurationmodel OWNER TO postgres;

--
-- Data for Name: strokehealthcaremodel_admittancedepartmentmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_admittancedepartmentmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_admittancedepartmentmodel (id, name) FROM '$$PATH$$/3644.dat';

--
-- Data for Name: strokehealthcaremodel_afibfluttermodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_afibfluttermodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_afibfluttermodel (id, name) FROM '$$PATH$$/3645.dat';

--
-- Data for Name: strokehealthcaremodel_arrivalmodemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_arrivalmodemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_arrivalmodemodel (id, name) FROM '$$PATH$$/3646.dat';

--
-- Data for Name: strokehealthcaremodel_bleedingantidotemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_bleedingantidotemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_bleedingantidotemodel (id, name) FROM '$$PATH$$/3647.dat';

--
-- Data for Name: strokehealthcaremodel_carotidstenosisfollowuptimingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel (id, name) FROM '$$PATH$$/3648.dat';

--
-- Data for Name: strokehealthcaremodel_carotidstenosislevelmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_carotidstenosislevelmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_carotidstenosislevelmodel (id, name) FROM '$$PATH$$/3649.dat';

--
-- Data for Name: strokehealthcaremodel_departmenttypemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_departmenttypemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_departmenttypemodel (id, name) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: strokehealthcaremodel_dischargedestinationmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_dischargedestinationmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_dischargedestinationmodel (id, name) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: strokehealthcaremodel_dischargefacilitydepartmentmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_dischargefacilitydepartmentmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_dischargefacilitydepartmentmodel (id, name) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: strokehealthcaremodel_dischargefacilitytypemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_dischargefacilitytypemodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_dischargefacilitytypemodel (id, name, "desc") FROM '$$PATH$$/3653.dat';

--
-- Data for Name: strokehealthcaremodel_gcslevelmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_gcslevelmodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_gcslevelmodel (id, name, "desc") FROM '$$PATH$$/3654.dat';

--
-- Data for Name: strokehealthcaremodel_hospitalizedinmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_hospitalizedinmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_hospitalizedinmodel (id, name) FROM '$$PATH$$/3655.dat';

--
-- Data for Name: strokehealthcaremodel_imagingdonemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_imagingdonemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_imagingdonemodel (id, name) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: strokehealthcaremodel_imagingtypemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_imagingtypemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_imagingtypemodel (id, name) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: strokehealthcaremodel_inrmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_inrmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_inrmodel (id, name) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: strokehealthcaremodel_insulintimingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_insulintimingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_insulintimingmodel (id, name) FROM '$$PATH$$/3659.dat';

--
-- Data for Name: strokehealthcaremodel_ivtapplicationlocationmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_ivtapplicationlocationmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_ivtapplicationlocationmodel (id, name) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: strokehealthcaremodel_ivttreatmentmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_ivttreatmentmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_ivttreatmentmodel (id, name) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: strokehealthcaremodel_modecontactmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_modecontactmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_modecontactmodel (id, name) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: strokehealthcaremodel_mticiscoremodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_mticiscoremodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_mticiscoremodel (id, name, "desc") FROM '$$PATH$$/3663.dat';

--
-- Data for Name: strokehealthcaremodel_nimodipinetimingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_nimodipinetimingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_nimodipinetimingmodel (id, name) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: strokehealthcaremodel_nothrombectomyreasonmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_nothrombectomyreasonmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_nothrombectomyreasonmodel (id, name) FROM '$$PATH$$/3665.dat';

--
-- Data for Name: strokehealthcaremodel_nothrombolysisreasonmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_nothrombolysisreasonmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_nothrombolysisreasonmodel (id, name) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: strokehealthcaremodel_occupationaltherapydonemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_occupationaltherapydonemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_occupationaltherapydonemodel (id, name) FROM '$$PATH$$/3667.dat';

--
-- Data for Name: strokehealthcaremodel_paracetamolmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_paracetamolmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_paracetamolmodel (id, name) FROM '$$PATH$$/3668.dat';

--
-- Data for Name: strokehealthcaremodel_paracetamoltimingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_paracetamoltimingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_paracetamoltimingmodel (id, name) FROM '$$PATH$$/3669.dat';

--
-- Data for Name: strokehealthcaremodel_physiotherapydonemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_physiotherapydonemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_physiotherapydonemodel (id, name) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: strokehealthcaremodel_postacutecaremodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_postacutecaremodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_postacutecaremodel (id, name) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: strokehealthcaremodel_posttreatmentimagingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_posttreatmentimagingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_posttreatmentimagingmodel (id, name) FROM '$$PATH$$/3672.dat';

--
-- Data for Name: strokehealthcaremodel_sexmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_sexmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_sexmodel (id, name) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: strokehealthcaremodel_smokingcessationmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_smokingcessationmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_smokingcessationmodel (id, name) FROM '$$PATH$$/3674.dat';

--
-- Data for Name: strokehealthcaremodel_speechtherapydonemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_speechtherapydonemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_speechtherapydonemodel (id, name) FROM '$$PATH$$/3675.dat';

--
-- Data for Name: strokehealthcaremodel_strokehealthcaremodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_strokehealthcaremodel (subject_id, label, validator_id, study_id, patient_date_created, patient_owner, patient_data_updated, age, wake_up_stroke, hospital_stroke, sleep_timestamp, onset_timestamp, onset_time_known, hospital_timestamp, first_hospital, first_arrival_hospital, prenotification, risk_hypertension, risk_diabetes, risk_hyperlipidemia, risk_atrial_fibrilation, risk_congestive_heart_failure, risk_smoker_last_10_years, risk_smoker, risk_previous_stroke, risk_previous_ischemic_stroke, risk_previous_hemorrhagic_stroke, risk_coronary_artery_disease_or_myocardial_infarction, risk_hiv, risk_covid, risk_other, before_onset_antidiabetics, before_onset_antihypertensives, before_onset_asa, before_onset_cilostazol, before_onset_clopidrogel, before_onset_ticagrelor, before_onset_ticlopidine, before_onset_prasugrel, before_onset_dipyridamol, before_onset_other_antiplatelet, before_onset_warfarin, before_onset_dabigatran, before_onset_rivaroxaban, before_onset_apixaban, before_onset_edoxaban, before_onset_other_anticoagulant, before_onset_statin, before_onset_heparin, before_onset_contraception, before_onset_other, glucose, cholesterol, sys_blood_pressure, dia_blood_pressure, nihss_score, prestroke_mrs, gcs_score, imaging_timestamp, imaging_within_hour, old_infarcts_cortical, old_infarcts_subcortical, old_infarcts_brainstem, aspects_score, occlusion_on_angio, occlusion_left_mca_m1, occlusion_left_mca_m2, occlusion_left_mca_m3, occlusion_left_aca, occlusion_left_pca_p1, occlusion_left_pca_p2, occlusion_left_cae, occlusion_left_cai, occlusion_right_mca_m1, occlusion_right_mca_m2, occlusion_right_mca_m3, occlusion_right_aca, occlusion_right_pca_p1, occlusion_right_pca_p2, occlusion_right_cae, occlusion_right_cai, occlusion_ba, occlusion_va, perfusion_deficit_medial, perfusion_deficit_anterior, perfusion_deficit_posterior, perfusion_deficit_carotid, perfusion_deficit_bilateral_stenosis, perfusion_deficit_done, perfusion_core, hypoperfusion_core, thrombolysis, ivt_antidote, ivt_dose, bolus_timestamp, door_to_needle, thrombectomy, puncture_timestamp, door_to_groin, reperfusion_timestamp, transfer_timestamp, door_to_door, complications_perforation, complications_dissection, complications_embolization, complications_hematoma, complications_other, bleeding_volume_value, bleeding_volume_over_30, infratentorial_source, bleeding_source, intraventricular_hemorrhage, bleeding_reason_hypertension, bleeding_reason_aneurysm, bleeding_reason_malformation, bleeding_reason_anticoagulant, bleeding_reason_angiopathy, bleeding_reason_other, neurosurgery, ich_treatment_evacuation, ich_treatment_drainage, ich_treatment_craniectomy, hunt_hess_score, sah_treatment_coiling, sah_treatment_clipping, sah_treatment_drainage, sah_treatment_craniectomy, sah_treatment_other, nimodipine, cvt_treatment_anticoagulation, cvt_treatment_thrombectomy, cvt_treatment_thrombolysis, cvt_treatment_neurosurgery, stroke_mimics_ivt, ventilator, hemicraniectomy, carotid_arteries_imaging, carotid_stenosis, carotid_stenosis_followup, holter_monitoring, etiology_large_artery, etiology_cardioembolism, etiology_other, etiology_cryptogenic_stroke, etiology_small_vessel, thromboembolism_lduh, thromboembolism_lmwh, thromboembolism_ipc, thromboembolism_gcs, thromboembolism_warfarin, thromboembolism_vfp, thromboembolism_oral_factorxa_inhibitor, thromboembolism_other, post_stroke_pneumonia, post_stroke_dvt, post_stroke_embolism, post_stroke_infection, post_stroke_sores, post_stroke_sepsis, post_stroke_extension, post_stroke_other, post_treatment_infarction, post_treatment_no_bleeding, post_treatment_remote, post_treatment_hi_i, post_treatment_hi_ii, post_treatment_ph_i, post_treatment_ph_ii, temp_check_day_one, temp_check_day_two, temp_check_day_three, fever, glucose_check_day_one, glucose_check_day_two, glucose_check_day_three, glucose_level, insulin, discharge_date, discharge_mrs, discharge_nihss_score, discharge_antidiabetics, discharge_antihypertensives, discharge_asa, discharge_cilostazol, discharge_clopidrogel, discharge_ticagrelor, discharge_ticlopidine, discharge_prasugrel, discharge_dipyridamol, discharge_warfarin, discharge_dabigatran, discharge_rivaroxaban, discharge_apixaban, discharge_edoxaban, discharge_statin, discharge_heparin, discharge_anticoagulant_recommended, discharge_other_anticoagulant, discharge_antiplatelet_recommended, discharge_other_antiplatelet, discharge_other, contact_date, three_m_mrs, admittance_department_id, afib_flutter_id, arrival_mode_id, bleeding_antidote_id, carotid_stenosis_followup_timing_id, carotid_stenosis_level_id, department_type_id, discharge_destination_id, discharge_facility_department_id, discharge_facility_type_id, gcs_level_id, hospitalized_in_id, imaging_done_id, imaging_type_id, inr_id, insulin_timing_id, ivt_application_location_id, ivt_treatment_id, mode_contact_id, mtici_score_id, nimodipine_timing_id, no_thrombectomy_reason_id, no_thrombolysis_reason_id, occup_physiotherapy_done_id, paracetamol_id, paracetamol_timing_id, physiotherapy_done_id, post_acute_care_id, post_treatment_imaging_id, sex_id, smoking_cessation_id, speech_therapy_done_id, stroke_management_appointment_id, stroke_mimics_diagnosis_id, stroke_type_id, swallowing_assessment_by_id, swallowing_screening_done_id, swallowing_screening_timing_id, swallowing_screening_type_id, tia_clinical_features_id, tia_symptoms_duration_id) FROM stdin;
\.
COPY public.strokehealthcaremodel_strokehealthcaremodel (subject_id, label, validator_id, study_id, patient_date_created, patient_owner, patient_data_updated, age, wake_up_stroke, hospital_stroke, sleep_timestamp, onset_timestamp, onset_time_known, hospital_timestamp, first_hospital, first_arrival_hospital, prenotification, risk_hypertension, risk_diabetes, risk_hyperlipidemia, risk_atrial_fibrilation, risk_congestive_heart_failure, risk_smoker_last_10_years, risk_smoker, risk_previous_stroke, risk_previous_ischemic_stroke, risk_previous_hemorrhagic_stroke, risk_coronary_artery_disease_or_myocardial_infarction, risk_hiv, risk_covid, risk_other, before_onset_antidiabetics, before_onset_antihypertensives, before_onset_asa, before_onset_cilostazol, before_onset_clopidrogel, before_onset_ticagrelor, before_onset_ticlopidine, before_onset_prasugrel, before_onset_dipyridamol, before_onset_other_antiplatelet, before_onset_warfarin, before_onset_dabigatran, before_onset_rivaroxaban, before_onset_apixaban, before_onset_edoxaban, before_onset_other_anticoagulant, before_onset_statin, before_onset_heparin, before_onset_contraception, before_onset_other, glucose, cholesterol, sys_blood_pressure, dia_blood_pressure, nihss_score, prestroke_mrs, gcs_score, imaging_timestamp, imaging_within_hour, old_infarcts_cortical, old_infarcts_subcortical, old_infarcts_brainstem, aspects_score, occlusion_on_angio, occlusion_left_mca_m1, occlusion_left_mca_m2, occlusion_left_mca_m3, occlusion_left_aca, occlusion_left_pca_p1, occlusion_left_pca_p2, occlusion_left_cae, occlusion_left_cai, occlusion_right_mca_m1, occlusion_right_mca_m2, occlusion_right_mca_m3, occlusion_right_aca, occlusion_right_pca_p1, occlusion_right_pca_p2, occlusion_right_cae, occlusion_right_cai, occlusion_ba, occlusion_va, perfusion_deficit_medial, perfusion_deficit_anterior, perfusion_deficit_posterior, perfusion_deficit_carotid, perfusion_deficit_bilateral_stenosis, perfusion_deficit_done, perfusion_core, hypoperfusion_core, thrombolysis, ivt_antidote, ivt_dose, bolus_timestamp, door_to_needle, thrombectomy, puncture_timestamp, door_to_groin, reperfusion_timestamp, transfer_timestamp, door_to_door, complications_perforation, complications_dissection, complications_embolization, complications_hematoma, complications_other, bleeding_volume_value, bleeding_volume_over_30, infratentorial_source, bleeding_source, intraventricular_hemorrhage, bleeding_reason_hypertension, bleeding_reason_aneurysm, bleeding_reason_malformation, bleeding_reason_anticoagulant, bleeding_reason_angiopathy, bleeding_reason_other, neurosurgery, ich_treatment_evacuation, ich_treatment_drainage, ich_treatment_craniectomy, hunt_hess_score, sah_treatment_coiling, sah_treatment_clipping, sah_treatment_drainage, sah_treatment_craniectomy, sah_treatment_other, nimodipine, cvt_treatment_anticoagulation, cvt_treatment_thrombectomy, cvt_treatment_thrombolysis, cvt_treatment_neurosurgery, stroke_mimics_ivt, ventilator, hemicraniectomy, carotid_arteries_imaging, carotid_stenosis, carotid_stenosis_followup, holter_monitoring, etiology_large_artery, etiology_cardioembolism, etiology_other, etiology_cryptogenic_stroke, etiology_small_vessel, thromboembolism_lduh, thromboembolism_lmwh, thromboembolism_ipc, thromboembolism_gcs, thromboembolism_warfarin, thromboembolism_vfp, thromboembolism_oral_factorxa_inhibitor, thromboembolism_other, post_stroke_pneumonia, post_stroke_dvt, post_stroke_embolism, post_stroke_infection, post_stroke_sores, post_stroke_sepsis, post_stroke_extension, post_stroke_other, post_treatment_infarction, post_treatment_no_bleeding, post_treatment_remote, post_treatment_hi_i, post_treatment_hi_ii, post_treatment_ph_i, post_treatment_ph_ii, temp_check_day_one, temp_check_day_two, temp_check_day_three, fever, glucose_check_day_one, glucose_check_day_two, glucose_check_day_three, glucose_level, insulin, discharge_date, discharge_mrs, discharge_nihss_score, discharge_antidiabetics, discharge_antihypertensives, discharge_asa, discharge_cilostazol, discharge_clopidrogel, discharge_ticagrelor, discharge_ticlopidine, discharge_prasugrel, discharge_dipyridamol, discharge_warfarin, discharge_dabigatran, discharge_rivaroxaban, discharge_apixaban, discharge_edoxaban, discharge_statin, discharge_heparin, discharge_anticoagulant_recommended, discharge_other_anticoagulant, discharge_antiplatelet_recommended, discharge_other_antiplatelet, discharge_other, contact_date, three_m_mrs, admittance_department_id, afib_flutter_id, arrival_mode_id, bleeding_antidote_id, carotid_stenosis_followup_timing_id, carotid_stenosis_level_id, department_type_id, discharge_destination_id, discharge_facility_department_id, discharge_facility_type_id, gcs_level_id, hospitalized_in_id, imaging_done_id, imaging_type_id, inr_id, insulin_timing_id, ivt_application_location_id, ivt_treatment_id, mode_contact_id, mtici_score_id, nimodipine_timing_id, no_thrombectomy_reason_id, no_thrombolysis_reason_id, occup_physiotherapy_done_id, paracetamol_id, paracetamol_timing_id, physiotherapy_done_id, post_acute_care_id, post_treatment_imaging_id, sex_id, smoking_cessation_id, speech_therapy_done_id, stroke_management_appointment_id, stroke_mimics_diagnosis_id, stroke_type_id, swallowing_assessment_by_id, swallowing_screening_done_id, swallowing_screening_timing_id, swallowing_screening_type_id, tia_clinical_features_id, tia_symptoms_duration_id) FROM '$$PATH$$/3676.dat';

--
-- Data for Name: strokehealthcaremodel_strokemanagementappointmentmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_strokemanagementappointmentmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_strokemanagementappointmentmodel (id, name) FROM '$$PATH$$/3677.dat';

--
-- Data for Name: strokehealthcaremodel_strokemimicsdiagnosismodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_strokemimicsdiagnosismodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_strokemimicsdiagnosismodel (id, name) FROM '$$PATH$$/3678.dat';

--
-- Data for Name: strokehealthcaremodel_stroketypemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_stroketypemodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_stroketypemodel (id, name, "desc") FROM '$$PATH$$/3679.dat';

--
-- Data for Name: strokehealthcaremodel_swallowingassessmentmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_swallowingassessmentmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_swallowingassessmentmodel (id, name) FROM '$$PATH$$/3680.dat';

--
-- Data for Name: strokehealthcaremodel_swallowingscreeningdonemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_swallowingscreeningdonemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_swallowingscreeningdonemodel (id, name) FROM '$$PATH$$/3681.dat';

--
-- Data for Name: strokehealthcaremodel_swallowingscreeningtimingmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_swallowingscreeningtimingmodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_swallowingscreeningtimingmodel (id, name) FROM '$$PATH$$/3682.dat';

--
-- Data for Name: strokehealthcaremodel_swallowingscreeningtypemodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_swallowingscreeningtypemodel (id, name) FROM stdin;
\.
COPY public.strokehealthcaremodel_swallowingscreeningtypemodel (id, name) FROM '$$PATH$$/3683.dat';

--
-- Data for Name: strokehealthcaremodel_tiaclinicalfeaturesmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_tiaclinicalfeaturesmodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_tiaclinicalfeaturesmodel (id, name, "desc") FROM '$$PATH$$/3684.dat';

--
-- Data for Name: strokehealthcaremodel_tiasymptomsdurationmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strokehealthcaremodel_tiasymptomsdurationmodel (id, name, "desc") FROM stdin;
\.
COPY public.strokehealthcaremodel_tiasymptomsdurationmodel (id, name, "desc") FROM '$$PATH$$/3685.dat';

--
-- Name: strokehealthcaremodel_admittancedepartmentmodel strokehealthcaremodel_admittancedepartmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_admittancedepartmentmodel
    ADD CONSTRAINT strokehealthcaremodel_admittancedepartmentmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_afibfluttermodel strokehealthcaremodel_afibfluttermodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_afibfluttermodel
    ADD CONSTRAINT strokehealthcaremodel_afibfluttermodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_arrivalmodemodel strokehealthcaremodel_arrivalmodemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_arrivalmodemodel
    ADD CONSTRAINT strokehealthcaremodel_arrivalmodemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_bleedingantidotemodel strokehealthcaremodel_bleedingantidotemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_bleedingantidotemodel
    ADD CONSTRAINT strokehealthcaremodel_bleedingantidotemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_carotidstenosisfollowuptimingmodel strokehealthcaremodel_carotidstenosisfollowuptimingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel
    ADD CONSTRAINT strokehealthcaremodel_carotidstenosisfollowuptimingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_carotidstenosislevelmodel strokehealthcaremodel_carotidstenosislevelmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_carotidstenosislevelmodel
    ADD CONSTRAINT strokehealthcaremodel_carotidstenosislevelmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_departmenttypemodel strokehealthcaremodel_departmenttypemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_departmenttypemodel
    ADD CONSTRAINT strokehealthcaremodel_departmenttypemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_dischargedestinationmodel strokehealthcaremodel_dischargedestinationmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_dischargedestinationmodel
    ADD CONSTRAINT strokehealthcaremodel_dischargedestinationmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_dischargefacilitydepartmentmodel strokehealthcaremodel_dischargefacilitydepartmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_dischargefacilitydepartmentmodel
    ADD CONSTRAINT strokehealthcaremodel_dischargefacilitydepartmentmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_dischargefacilitytypemodel strokehealthcaremodel_dischargefacilitytypemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_dischargefacilitytypemodel
    ADD CONSTRAINT strokehealthcaremodel_dischargefacilitytypemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_gcslevelmodel strokehealthcaremodel_gcslevelmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_gcslevelmodel
    ADD CONSTRAINT strokehealthcaremodel_gcslevelmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_hospitalizedinmodel strokehealthcaremodel_hospitalizedinmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_hospitalizedinmodel
    ADD CONSTRAINT strokehealthcaremodel_hospitalizedinmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_imagingdonemodel strokehealthcaremodel_imagingdonemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_imagingdonemodel
    ADD CONSTRAINT strokehealthcaremodel_imagingdonemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_imagingtypemodel strokehealthcaremodel_imagingtypemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_imagingtypemodel
    ADD CONSTRAINT strokehealthcaremodel_imagingtypemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_inrmodel strokehealthcaremodel_inrmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_inrmodel
    ADD CONSTRAINT strokehealthcaremodel_inrmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_insulintimingmodel strokehealthcaremodel_insulintimingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_insulintimingmodel
    ADD CONSTRAINT strokehealthcaremodel_insulintimingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_ivtapplicationlocationmodel strokehealthcaremodel_ivtapplicationlocationmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_ivtapplicationlocationmodel
    ADD CONSTRAINT strokehealthcaremodel_ivtapplicationlocationmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_ivttreatmentmodel strokehealthcaremodel_ivttreatmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_ivttreatmentmodel
    ADD CONSTRAINT strokehealthcaremodel_ivttreatmentmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_modecontactmodel strokehealthcaremodel_modecontactmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_modecontactmodel
    ADD CONSTRAINT strokehealthcaremodel_modecontactmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_mticiscoremodel strokehealthcaremodel_mticiscoremodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_mticiscoremodel
    ADD CONSTRAINT strokehealthcaremodel_mticiscoremodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_nimodipinetimingmodel strokehealthcaremodel_nimodipinetimingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_nimodipinetimingmodel
    ADD CONSTRAINT strokehealthcaremodel_nimodipinetimingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_nothrombectomyreasonmodel strokehealthcaremodel_nothrombectomyreasonmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_nothrombectomyreasonmodel
    ADD CONSTRAINT strokehealthcaremodel_nothrombectomyreasonmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_nothrombolysisreasonmodel strokehealthcaremodel_nothrombolysisreasonmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_nothrombolysisreasonmodel
    ADD CONSTRAINT strokehealthcaremodel_nothrombolysisreasonmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_occupationaltherapydonemodel strokehealthcaremodel_occupationaltherapydonemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_occupationaltherapydonemodel
    ADD CONSTRAINT strokehealthcaremodel_occupationaltherapydonemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_paracetamolmodel strokehealthcaremodel_paracetamolmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_paracetamolmodel
    ADD CONSTRAINT strokehealthcaremodel_paracetamolmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_paracetamoltimingmodel strokehealthcaremodel_paracetamoltimingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_paracetamoltimingmodel
    ADD CONSTRAINT strokehealthcaremodel_paracetamoltimingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_physiotherapydonemodel strokehealthcaremodel_physiotherapydonemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_physiotherapydonemodel
    ADD CONSTRAINT strokehealthcaremodel_physiotherapydonemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_postacutecaremodel strokehealthcaremodel_postacutecaremodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_postacutecaremodel
    ADD CONSTRAINT strokehealthcaremodel_postacutecaremodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_posttreatmentimagingmodel strokehealthcaremodel_posttreatmentimagingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_posttreatmentimagingmodel
    ADD CONSTRAINT strokehealthcaremodel_posttreatmentimagingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_sexmodel strokehealthcaremodel_sexmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_sexmodel
    ADD CONSTRAINT strokehealthcaremodel_sexmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_smokingcessationmodel strokehealthcaremodel_smokingcessationmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_smokingcessationmodel
    ADD CONSTRAINT strokehealthcaremodel_smokingcessationmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_speechtherapydonemodel strokehealthcaremodel_speechtherapydonemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_speechtherapydonemodel
    ADD CONSTRAINT strokehealthcaremodel_speechtherapydonemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremodel_strokehealthcaremodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremodel_strokehealthcaremodel_pkey PRIMARY KEY (subject_id);


--
-- Name: strokehealthcaremodel_strokemanagementappointmentmodel strokehealthcaremodel_strokemanagementappointmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokemanagementappointmentmodel
    ADD CONSTRAINT strokehealthcaremodel_strokemanagementappointmentmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_strokemimicsdiagnosismodel strokehealthcaremodel_strokemimicsdiagnosismodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokemimicsdiagnosismodel
    ADD CONSTRAINT strokehealthcaremodel_strokemimicsdiagnosismodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_stroketypemodel strokehealthcaremodel_stroketypemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_stroketypemodel
    ADD CONSTRAINT strokehealthcaremodel_stroketypemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_swallowingassessmentmodel strokehealthcaremodel_swallowingassessmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_swallowingassessmentmodel
    ADD CONSTRAINT strokehealthcaremodel_swallowingassessmentmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_swallowingscreeningdonemodel strokehealthcaremodel_swallowingscreeningdonemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_swallowingscreeningdonemodel
    ADD CONSTRAINT strokehealthcaremodel_swallowingscreeningdonemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_swallowingscreeningtimingmodel strokehealthcaremodel_swallowingscreeningtimingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_swallowingscreeningtimingmodel
    ADD CONSTRAINT strokehealthcaremodel_swallowingscreeningtimingmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_swallowingscreeningtypemodel strokehealthcaremodel_swallowingscreeningtypemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_swallowingscreeningtypemodel
    ADD CONSTRAINT strokehealthcaremodel_swallowingscreeningtypemodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_tiaclinicalfeaturesmodel strokehealthcaremodel_tiaclinicalfeaturesmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_tiaclinicalfeaturesmodel
    ADD CONSTRAINT strokehealthcaremodel_tiaclinicalfeaturesmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_tiasymptomsdurationmodel strokehealthcaremodel_tiasymptomsdurationmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_tiasymptomsdurationmodel
    ADD CONSTRAINT strokehealthcaremodel_tiasymptomsdurationmodel_pkey PRIMARY KEY (id);


--
-- Name: strokehealthcaremodel_stro_admittance_department_id_1b6a4069; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_admittance_department_id_1b6a4069 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (admittance_department_id);


--
-- Name: strokehealthcaremodel_stro_afib_flutter_id_4cd945db; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_afib_flutter_id_4cd945db ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (afib_flutter_id);


--
-- Name: strokehealthcaremodel_stro_arrival_mode_id_b313d610; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_arrival_mode_id_b313d610 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (arrival_mode_id);


--
-- Name: strokehealthcaremodel_stro_bleeding_antidote_id_2cd26821; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_bleeding_antidote_id_2cd26821 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (bleeding_antidote_id);


--
-- Name: strokehealthcaremodel_stro_carotid_stenosis_followup__0b748bc8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_carotid_stenosis_followup__0b748bc8 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (carotid_stenosis_followup_timing_id);


--
-- Name: strokehealthcaremodel_stro_carotid_stenosis_level_id_5158ea5c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_carotid_stenosis_level_id_5158ea5c ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (carotid_stenosis_level_id);


--
-- Name: strokehealthcaremodel_stro_department_type_id_8c599c85; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_department_type_id_8c599c85 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (department_type_id);


--
-- Name: strokehealthcaremodel_stro_discharge_destination_id_a27cd78c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_discharge_destination_id_a27cd78c ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (discharge_destination_id);


--
-- Name: strokehealthcaremodel_stro_discharge_facility_departm_bceb5523; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_discharge_facility_departm_bceb5523 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (discharge_facility_department_id);


--
-- Name: strokehealthcaremodel_stro_discharge_facility_type_id_41531f30; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_discharge_facility_type_id_41531f30 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (discharge_facility_type_id);


--
-- Name: strokehealthcaremodel_stro_gcs_level_id_8ea72c0a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_gcs_level_id_8ea72c0a ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (gcs_level_id);


--
-- Name: strokehealthcaremodel_stro_hospitalized_in_id_3e39b720; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_hospitalized_in_id_3e39b720 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (hospitalized_in_id);


--
-- Name: strokehealthcaremodel_stro_imaging_done_id_c37c5740; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_imaging_done_id_c37c5740 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (imaging_done_id);


--
-- Name: strokehealthcaremodel_stro_imaging_type_id_19e60191; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_imaging_type_id_19e60191 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (imaging_type_id);


--
-- Name: strokehealthcaremodel_stro_insulin_timing_id_5294d1e2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_insulin_timing_id_5294d1e2 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (insulin_timing_id);


--
-- Name: strokehealthcaremodel_stro_ivt_application_location_i_596a49a2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_ivt_application_location_i_596a49a2 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (ivt_application_location_id);


--
-- Name: strokehealthcaremodel_stro_ivt_treatment_id_2091de44; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_ivt_treatment_id_2091de44 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (ivt_treatment_id);


--
-- Name: strokehealthcaremodel_stro_mode_contact_id_6a14d06f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_mode_contact_id_6a14d06f ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (mode_contact_id);


--
-- Name: strokehealthcaremodel_stro_mtici_score_id_a8ab37ec; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_mtici_score_id_a8ab37ec ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (mtici_score_id);


--
-- Name: strokehealthcaremodel_stro_nimodipine_timing_id_1d0e4f1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_nimodipine_timing_id_1d0e4f1c ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (nimodipine_timing_id);


--
-- Name: strokehealthcaremodel_stro_no_thrombectomy_reason_id_f49e7dba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_no_thrombectomy_reason_id_f49e7dba ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (no_thrombectomy_reason_id);


--
-- Name: strokehealthcaremodel_stro_no_thrombolysis_reason_id_a52e115a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_no_thrombolysis_reason_id_a52e115a ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (no_thrombolysis_reason_id);


--
-- Name: strokehealthcaremodel_stro_occup_physiotherapy_done_i_6c865026; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_occup_physiotherapy_done_i_6c865026 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (occup_physiotherapy_done_id);


--
-- Name: strokehealthcaremodel_stro_paracetamol_id_91957d3f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_paracetamol_id_91957d3f ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (paracetamol_id);


--
-- Name: strokehealthcaremodel_stro_paracetamol_timing_id_46cf153c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_paracetamol_timing_id_46cf153c ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (paracetamol_timing_id);


--
-- Name: strokehealthcaremodel_stro_physiotherapy_done_id_fba25cee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_physiotherapy_done_id_fba25cee ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (physiotherapy_done_id);


--
-- Name: strokehealthcaremodel_stro_post_acute_care_id_a89d896a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_post_acute_care_id_a89d896a ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (post_acute_care_id);


--
-- Name: strokehealthcaremodel_stro_post_treatment_imaging_id_a516ad8d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_post_treatment_imaging_id_a516ad8d ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (post_treatment_imaging_id);


--
-- Name: strokehealthcaremodel_stro_smoking_cessation_id_35765611; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_smoking_cessation_id_35765611 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (smoking_cessation_id);


--
-- Name: strokehealthcaremodel_stro_speech_therapy_done_id_49f19675; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_speech_therapy_done_id_49f19675 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (speech_therapy_done_id);


--
-- Name: strokehealthcaremodel_stro_stroke_management_appointm_058c946b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_stroke_management_appointm_058c946b ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (stroke_management_appointment_id);


--
-- Name: strokehealthcaremodel_stro_stroke_mimics_diagnosis_id_dc60df85; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_stroke_mimics_diagnosis_id_dc60df85 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (stroke_mimics_diagnosis_id);


--
-- Name: strokehealthcaremodel_stro_stroke_type_id_b2d4ee2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_stroke_type_id_b2d4ee2c ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (stroke_type_id);


--
-- Name: strokehealthcaremodel_stro_swallowing_assessment_by_i_d0ad9e28; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_swallowing_assessment_by_i_d0ad9e28 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (swallowing_assessment_by_id);


--
-- Name: strokehealthcaremodel_stro_swallowing_screening_done__604711a5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_swallowing_screening_done__604711a5 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (swallowing_screening_done_id);


--
-- Name: strokehealthcaremodel_stro_swallowing_screening_timin_da598302; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_swallowing_screening_timin_da598302 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (swallowing_screening_timing_id);


--
-- Name: strokehealthcaremodel_stro_swallowing_screening_type__a4019a30; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_swallowing_screening_type__a4019a30 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (swallowing_screening_type_id);


--
-- Name: strokehealthcaremodel_stro_tia_clinical_features_id_21cb76d2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_tia_clinical_features_id_21cb76d2 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (tia_clinical_features_id);


--
-- Name: strokehealthcaremodel_stro_tia_symptoms_duration_id_306ba4f7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_stro_tia_symptoms_duration_id_306ba4f7 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (tia_symptoms_duration_id);


--
-- Name: strokehealthcaremodel_strokehealthcaremodel_inr_id_761c7073; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_strokehealthcaremodel_inr_id_761c7073 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (inr_id);


--
-- Name: strokehealthcaremodel_strokehealthcaremodel_sex_id_93142c04; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX strokehealthcaremodel_strokehealthcaremodel_sex_id_93142c04 ON public.strokehealthcaremodel_strokehealthcaremodel USING btree (sex_id);


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_admittance_departmen_1b6a4069_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_admittance_departmen_1b6a4069_fk_strokehea FOREIGN KEY (admittance_department_id) REFERENCES public.strokehealthcaremodel_admittancedepartmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_afib_flutter_id_4cd945db_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_afib_flutter_id_4cd945db_fk_strokehea FOREIGN KEY (afib_flutter_id) REFERENCES public.strokehealthcaremodel_afibfluttermodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_arrival_mode_id_b313d610_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_arrival_mode_id_b313d610_fk_strokehea FOREIGN KEY (arrival_mode_id) REFERENCES public.strokehealthcaremodel_arrivalmodemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_bleeding_antidote_id_2cd26821_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_bleeding_antidote_id_2cd26821_fk_strokehea FOREIGN KEY (bleeding_antidote_id) REFERENCES public.strokehealthcaremodel_bleedingantidotemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_carotid_stenosis_fol_0b748bc8_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_carotid_stenosis_fol_0b748bc8_fk_strokehea FOREIGN KEY (carotid_stenosis_followup_timing_id) REFERENCES public.strokehealthcaremodel_carotidstenosisfollowuptimingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_carotid_stenosis_lev_5158ea5c_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_carotid_stenosis_lev_5158ea5c_fk_strokehea FOREIGN KEY (carotid_stenosis_level_id) REFERENCES public.strokehealthcaremodel_carotidstenosislevelmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_department_type_id_8c599c85_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_department_type_id_8c599c85_fk_strokehea FOREIGN KEY (department_type_id) REFERENCES public.strokehealthcaremodel_departmenttypemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_discharge_destinatio_a27cd78c_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_discharge_destinatio_a27cd78c_fk_strokehea FOREIGN KEY (discharge_destination_id) REFERENCES public.strokehealthcaremodel_dischargedestinationmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_discharge_facility_d_bceb5523_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_discharge_facility_d_bceb5523_fk_strokehea FOREIGN KEY (discharge_facility_department_id) REFERENCES public.strokehealthcaremodel_dischargefacilitydepartmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_discharge_facility_t_41531f30_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_discharge_facility_t_41531f30_fk_strokehea FOREIGN KEY (discharge_facility_type_id) REFERENCES public.strokehealthcaremodel_dischargefacilitytypemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_gcs_level_id_8ea72c0a_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_gcs_level_id_8ea72c0a_fk_strokehea FOREIGN KEY (gcs_level_id) REFERENCES public.strokehealthcaremodel_gcslevelmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_hospitalized_in_id_3e39b720_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_hospitalized_in_id_3e39b720_fk_strokehea FOREIGN KEY (hospitalized_in_id) REFERENCES public.strokehealthcaremodel_hospitalizedinmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_imaging_done_id_c37c5740_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_imaging_done_id_c37c5740_fk_strokehea FOREIGN KEY (imaging_done_id) REFERENCES public.strokehealthcaremodel_imagingdonemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_imaging_type_id_19e60191_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_imaging_type_id_19e60191_fk_strokehea FOREIGN KEY (imaging_type_id) REFERENCES public.strokehealthcaremodel_imagingtypemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_inr_id_761c7073_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_inr_id_761c7073_fk_strokehea FOREIGN KEY (inr_id) REFERENCES public.strokehealthcaremodel_inrmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_insulin_timing_id_5294d1e2_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_insulin_timing_id_5294d1e2_fk_strokehea FOREIGN KEY (insulin_timing_id) REFERENCES public.strokehealthcaremodel_insulintimingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_ivt_application_loca_596a49a2_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_ivt_application_loca_596a49a2_fk_strokehea FOREIGN KEY (ivt_application_location_id) REFERENCES public.strokehealthcaremodel_ivtapplicationlocationmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_ivt_treatment_id_2091de44_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_ivt_treatment_id_2091de44_fk_strokehea FOREIGN KEY (ivt_treatment_id) REFERENCES public.strokehealthcaremodel_ivttreatmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_mode_contact_id_6a14d06f_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_mode_contact_id_6a14d06f_fk_strokehea FOREIGN KEY (mode_contact_id) REFERENCES public.strokehealthcaremodel_modecontactmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_mtici_score_id_a8ab37ec_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_mtici_score_id_a8ab37ec_fk_strokehea FOREIGN KEY (mtici_score_id) REFERENCES public.strokehealthcaremodel_mticiscoremodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_nimodipine_timing_id_1d0e4f1c_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_nimodipine_timing_id_1d0e4f1c_fk_strokehea FOREIGN KEY (nimodipine_timing_id) REFERENCES public.strokehealthcaremodel_nimodipinetimingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_no_thrombectomy_reas_f49e7dba_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_no_thrombectomy_reas_f49e7dba_fk_strokehea FOREIGN KEY (no_thrombectomy_reason_id) REFERENCES public.strokehealthcaremodel_nothrombectomyreasonmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_no_thrombolysis_reas_a52e115a_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_no_thrombolysis_reas_a52e115a_fk_strokehea FOREIGN KEY (no_thrombolysis_reason_id) REFERENCES public.strokehealthcaremodel_nothrombolysisreasonmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_occup_physiotherapy__6c865026_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_occup_physiotherapy__6c865026_fk_strokehea FOREIGN KEY (occup_physiotherapy_done_id) REFERENCES public.strokehealthcaremodel_occupationaltherapydonemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_paracetamol_id_91957d3f_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_paracetamol_id_91957d3f_fk_strokehea FOREIGN KEY (paracetamol_id) REFERENCES public.strokehealthcaremodel_paracetamolmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_paracetamol_timing_i_46cf153c_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_paracetamol_timing_i_46cf153c_fk_strokehea FOREIGN KEY (paracetamol_timing_id) REFERENCES public.strokehealthcaremodel_paracetamoltimingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_physiotherapy_done_i_fba25cee_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_physiotherapy_done_i_fba25cee_fk_strokehea FOREIGN KEY (physiotherapy_done_id) REFERENCES public.strokehealthcaremodel_physiotherapydonemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_post_acute_care_id_a89d896a_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_post_acute_care_id_a89d896a_fk_strokehea FOREIGN KEY (post_acute_care_id) REFERENCES public.strokehealthcaremodel_postacutecaremodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_post_treatment_imagi_a516ad8d_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_post_treatment_imagi_a516ad8d_fk_strokehea FOREIGN KEY (post_treatment_imaging_id) REFERENCES public.strokehealthcaremodel_posttreatmentimagingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_sex_id_93142c04_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_sex_id_93142c04_fk_strokehea FOREIGN KEY (sex_id) REFERENCES public.strokehealthcaremodel_sexmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_smoking_cessation_id_35765611_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_smoking_cessation_id_35765611_fk_strokehea FOREIGN KEY (smoking_cessation_id) REFERENCES public.strokehealthcaremodel_smokingcessationmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_speech_therapy_done__49f19675_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_speech_therapy_done__49f19675_fk_strokehea FOREIGN KEY (speech_therapy_done_id) REFERENCES public.strokehealthcaremodel_speechtherapydonemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_stroke_management_ap_058c946b_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_stroke_management_ap_058c946b_fk_strokehea FOREIGN KEY (stroke_management_appointment_id) REFERENCES public.strokehealthcaremodel_strokemanagementappointmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_stroke_mimics_diagno_dc60df85_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_stroke_mimics_diagno_dc60df85_fk_strokehea FOREIGN KEY (stroke_mimics_diagnosis_id) REFERENCES public.strokehealthcaremodel_strokemimicsdiagnosismodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_stroke_type_id_b2d4ee2c_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_stroke_type_id_b2d4ee2c_fk_strokehea FOREIGN KEY (stroke_type_id) REFERENCES public.strokehealthcaremodel_stroketypemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_swallowing_assessmen_d0ad9e28_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_swallowing_assessmen_d0ad9e28_fk_strokehea FOREIGN KEY (swallowing_assessment_by_id) REFERENCES public.strokehealthcaremodel_swallowingassessmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_swallowing_screening_604711a5_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_swallowing_screening_604711a5_fk_strokehea FOREIGN KEY (swallowing_screening_done_id) REFERENCES public.strokehealthcaremodel_swallowingscreeningdonemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_swallowing_screening_a4019a30_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_swallowing_screening_a4019a30_fk_strokehea FOREIGN KEY (swallowing_screening_type_id) REFERENCES public.strokehealthcaremodel_swallowingscreeningtypemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_swallowing_screening_da598302_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_swallowing_screening_da598302_fk_strokehea FOREIGN KEY (swallowing_screening_timing_id) REFERENCES public.strokehealthcaremodel_swallowingscreeningtimingmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_tia_clinical_feature_21cb76d2_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_tia_clinical_feature_21cb76d2_fk_strokehea FOREIGN KEY (tia_clinical_features_id) REFERENCES public.strokehealthcaremodel_tiaclinicalfeaturesmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: strokehealthcaremodel_strokehealthcaremodel strokehealthcaremode_tia_symptoms_duratio_306ba4f7_fk_strokehea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strokehealthcaremodel_strokehealthcaremodel
    ADD CONSTRAINT strokehealthcaremode_tia_symptoms_duratio_306ba4f7_fk_strokehea FOREIGN KEY (tia_symptoms_duration_id) REFERENCES public.strokehealthcaremodel_tiasymptomsdurationmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

